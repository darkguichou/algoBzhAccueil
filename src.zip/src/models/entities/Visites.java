package models.entities;

import java.util.LinkedList;
import java.util.List;

public class Visites {
	
	
	List <Visite> visites = new LinkedList<Visite>();
	
	
	
	public Visites (){
		
		
		
		
		
	}
	
	
	
	
	public List<Visite> getVisites(){
		
		
		return visites;
		
	}
	
	

}
