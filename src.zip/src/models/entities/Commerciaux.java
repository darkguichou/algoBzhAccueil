package models.entities;

public class Commerciaux extends Clients {
	
	public Commerciaux(){
		
		super();
		
		
	}

}
