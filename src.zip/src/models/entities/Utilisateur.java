package models.entities;

/**
 * Created by guillaume on 28/04/16.
 */
public interface Utilisateur {

    void creer(int id, String code, String email, String nom, int codeZone);



}
