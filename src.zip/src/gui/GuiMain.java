package gui;

import gui.Application;

public class GuiMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {


        Application application = new Application();
        application.run();

	}

}
