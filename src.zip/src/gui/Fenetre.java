package gui;

import gui.views.ConnexionView;
import gui.views.View;

import javax.swing.*;
import java.awt.*;

public class Fenetre extends JFrame {


    private View view;
    private static final long serialVersionUID = 1L;

    public Fenetre(View view) {


        //<---------------------------------------------Construction de la classe-------------------------------------------------------------------------------------------->


        this.view = view;



        //Paramétrage de la Fenétre
        this.setTitle("Algo Breizh:");
        this.setMinimumSize(new Dimension(1500, 500));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setEnabled(true);
        this.setVisible(true);

        //Init avec la vue initiale
        this.getContentPane().add((ConnexionView)this.view, BorderLayout.CENTER);


    }



}
