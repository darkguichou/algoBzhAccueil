package gui;

import controllers.AjoutRdvController;
import controllers.ConnexionController;
import controllers.MenuController;
import dao.*;
import gui.views.*;
import listeners.AjouterRdvListener;
import listeners.ConnexionListener;
import listeners.MenuListener;
import models.AjouterRdvModel;
import models.ConnexionModel;
import models.ListeClientsModel;
import models.ListeVisitesModel;
import models.entities.Commercial;

import java.awt.event.MouseListener;
import java.util.Hashtable;
import java.util.Observer;

/**
 * Created by guillaume on 28/04/16.
 */
public class Application {


    private Db db;
    private Hashtable<String, Dao> daos = new Hashtable();
    private Hashtable<String, Object>models = new Hashtable();
    private Hashtable<String, View>views = new Hashtable();
    private Hashtable<String, MouseListener>listeners = new Hashtable();
    private Hashtable<String , Observer>controllers = new Hashtable();
    private Commercial commercial;
    private Fenetre fenetre;


    public Application(){

    }


    public void connexionDb(){


        Db db = new Db();
        db.connexion();
        this.db = db;

    }


    public void initDao(){


        CommercialDao commercialDao = new CommercialDao(db);
        ClientsDao clientsDao = new ClientsDao(db);
        VisitesDao visitesDao = new VisitesDao(db);
        daos.put("commercial", commercialDao);
        daos.put("clients", clientsDao);
        daos.put("visites", visitesDao);


    }


    public void initModels(){


        ConnexionModel connexion = new ConnexionModel((CommercialDao) daos.get("commercial"));
        AjouterRdvModel ajouterRdvModel = new AjouterRdvModel((VisitesDao)daos.get("visites"), (ClientsDao)daos.get("clients"));
        ListeClientsModel listeClients = new ListeClientsModel((ClientsDao) daos.get("clients"));
        ListeVisitesModel listeVisites = new ListeVisitesModel((VisitesDao)daos.get("visites"));

        models.put("connexion", connexion);
        models.put("ajouterRdv", ajouterRdvModel);
        models.put("listeClients", listeClients);
        models.put("listeVisites", listeVisites);


    }

    public void initViews(){

        ConnexionView connexionView = new ConnexionView();
        ListeClientView listeClientView = new ListeClientView();
        ListeVisitesView listeVisitesView = new ListeVisitesView();
        AjouterRdvView ajouterRdvView = new AjouterRdvView();

        views.put("connexion", connexionView);
        views.put("listeClients", listeClientView);
        views.put("listeVisites", listeVisitesView);
        views.put("ajouterRdv", ajouterRdvView);



    }

    public void initListeners(){

        ConnexionListener connexionListener = new ConnexionListener((ConnexionView)views.get("connexion"),(ConnexionModel)models.get("connexion"));
        MenuListener menuListener = new MenuListener(
                (ListeClientView)views.get("listeClients"),
                (ConnexionView)views.get("connexion"),
                (ListeVisitesView) views.get("listeVisites"),
                (AjouterRdvView)views.get("ajouterRdv")
                );
        AjouterRdvListener ajouterRdvListener = new AjouterRdvListener((AjouterRdvView)views.get("ajouterRdv"), (AjouterRdvModel)models.get("ajouterRdv"));

        listeners.put("connexion", connexionListener);
        listeners.put("menuListener", menuListener);
        listeners.put("ajouterRdv", ajouterRdvListener);

    }

    public void setListeners(){



        for(View v : views.values()){


            v.setListeners(listeners);

        }



    }


    public void createViews(){

        for (View v : views.values()){



            v.init();

        }


    }


    public void createControllers(){

        ConnexionController connexionController = new ConnexionController(fenetre, this);
        MenuController menuController = new MenuController(fenetre, this);
        AjoutRdvController ajoutRdvController = new AjoutRdvController(fenetre, this);
        controllers.put("connexion", connexionController);
        controllers.put("menu", menuController);
        controllers.put("ajoutRdv", ajoutRdvController);





    }

    public void initObservers(){


        MenuListener menuListener = (MenuListener)listeners.get("menuListener");
        ConnexionModel connexionModel = (ConnexionModel)models.get("connexion");
        AjouterRdvModel ajouterRdvModel = (AjouterRdvModel)models.get("ajouterRdv");
        menuListener.addObserver(controllers.get("menu"));
        connexionModel.addObserver(controllers.get("connexion"));
        ajouterRdvModel.addObserver(controllers.get("ajoutRdv"));



    }




    public void run(){


        connexionDb();
        initDao();
        initModels();
        initViews();
        initListeners();
        setListeners();
        createViews();
        Fenetre fenetre = new Fenetre(views.get("connexion"));
        this.fenetre = fenetre;
        createControllers();
        initObservers();



    }


    public Commercial getCommercial() {
        return commercial;
    }

    public void setCommercial(Commercial commercial) {
        this.commercial = commercial;
    }

    public Hashtable<String, Object> getModels() {
        return models;
    }

    public Hashtable<String, View> getViews() {
        return views;
    }

    public Hashtable<String, MouseListener> getListeners() {
        return listeners;
    }
}
