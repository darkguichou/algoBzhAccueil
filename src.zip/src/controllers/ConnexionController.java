package controllers;

import gui.Application;
import gui.Fenetre;
import gui.components.ListeClientTable;
import gui.views.ConnexionView;
import gui.views.ListeClientView;
import models.ConnexionModel;
import models.ListeClientsModel;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.Observable;

/**
 * Created by guillaume on 01/05/16.
 */
public class ConnexionController extends Controller {

    public ConnexionController(Fenetre fenetre, Application application) {
        super(fenetre, application);
    }

    @Override
    public void update(Observable o, Object arg) {


        ConnexionModel connexionModel = (ConnexionModel)application.getModels().get("connexion");

        //########CONNEXION -> VALIDE############
        if(connexionModel.getEtat()) {

            ListeClientsModel listeClientsModel = (ListeClientsModel)application.getModels().get("listeClients");
            ListeClientView listeClientView = (ListeClientView)application.getViews().get("listeClients");


            //Récupération du commercial renseigné à la connexion
            application.setCommercial(connexionModel.getCommercial());

            //Supperssion des vue active
            fenetre.getContentPane().removeAll();

            //Récupération des clients affectés au commercial et génération de la liste des clients
            listeClientsModel.setCodeZone(application.getCommercial().getZone());
            listeClientsModel.create();

            //Génération de l'affichage (JTable) en fonction de la liste des clients
            ListeClientTable table = new ListeClientTable(listeClientsModel.getUtilisateurs());
            table.create();

            //Ajout de l'affichage à la vue
            listeClientView.getTabPanel().setViewportView(table.getTable());
            fenetre.getContentPane().add(listeClientView);

            //Regénération de la vue
            fenetre.revalidate();
            fenetre.repaint();


            //###########CONNEXION -> NON-VALIDE#############
        } else {

            ConnexionView connexionView = (ConnexionView)application.getViews().get("connexion");

            //Ajout de bordures signalant une erreur d'identification
            Border border = BorderFactory.createLineBorder(Color.red);
            connexionView.getIdField().setBorder(border);
            connexionView.getPwdField().setBorder(border);

            //Ajout du message d'erreur
            connexionView.getError().setText("Erreur de connexion.");

            //Regénération de la vue et de la fenètre
            connexionView.revalidate();
            connexionView.repaint();
            fenetre.validate();


        }


    }
}
