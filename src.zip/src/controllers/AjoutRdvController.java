package controllers;

import gui.Application;
import gui.Fenetre;
import gui.views.AjouterRdvView;

import javax.swing.*;
import java.util.Observable;

/**
 * Created by guillaume on 01/05/16.
 */
public class AjoutRdvController extends Controller{

    public AjoutRdvController(Fenetre fenetre, Application application) {
        super(fenetre, application);
    }

    @Override
    public void update(Observable o, Object arg) {

        AjouterRdvView ajouterRdvView = (AjouterRdvView)application.getViews().get("ajouterRdv");


        //Ajout d'un message signalant que le rendez vous a bien été créé
        ajouterRdvView.getMessage().add(new JLabel("Votre visite a bien été ajoutée"));

        //Régération de la vue
        ajouterRdvView.getMessage().revalidate();
        ajouterRdvView.getMessage().repaint();
        ajouterRdvView.revalidate();
        ajouterRdvView.repaint();





    }
}
