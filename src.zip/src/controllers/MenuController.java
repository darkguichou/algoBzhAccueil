package controllers;

import gui.Application;
import gui.Fenetre;
import gui.components.ListeClientTable;
import gui.components.ListeVisitesTable;
import gui.views.AjouterRdvView;
import gui.views.ConnexionView;
import gui.views.ListeClientView;
import gui.views.ListeVisitesView;
import models.AjouterRdvModel;
import models.ListeClientsModel;
import models.ListeVisitesModel;

import javax.swing.*;
import java.awt.*;
import java.util.Observable;

/**
 * Created by guillaume on 01/05/16.
 */
public class MenuController extends Controller{


    public MenuController(Fenetre fenetre, Application application) {
        super(fenetre, application);
    }

    @Override
    public void update(Observable o, Object arg) {



        //################DECONNEXION##################
        if (arg == null) {

            ConnexionView connexionView = (ConnexionView)application.getViews().get("connexion");

            //Suppression de la vue active
            fenetre.getContentPane().removeAll();

            //Ajout de la vue correspondante
            fenetre.getContentPane().add(connexionView);

            //Régénératiopn de la fenètre
            fenetre.revalidate();
            fenetre.repaint();


        } else {

            ListeClientView listeClientView = (ListeClientView)application.getViews().get("listeClients");
            ListeVisitesView listeVisitesView = (ListeVisitesView)application.getViews().get("listeVisites");
            AjouterRdvView ajouterRdvView = (AjouterRdvView)application.getViews().get("ajouterRdv");


            //#################LISTE DES CLIENTS##################
            if (arg.equals(listeClientView)) {

                ListeClientsModel listeClientsModel = (ListeClientsModel)application.getModels().get("listeClients");


                //Suppressions de la vue active
                fenetre.getContentPane().removeAll();

                //Récupération de la liste des clients de la zone correspondante
                listeClientsModel.setCodeZone(application.getCommercial().getZone());
                listeClientsModel.create();

                //Génération de l'affichage de la laiste des clietns (JTable)
                ListeClientTable table = new ListeClientTable(listeClientsModel.getUtilisateurs());
                table.create();

                //Paramétrage de la vue
                listeClientView.getTabPanel().setViewportView(table.getTable());
                listeClientView.getMenu().getListeCilentsB().setBackground(Color.white);

                //Régénération de la vue et de la fenètre
                listeClientView.getMenu().revalidate();
                listeClientView.getMenu().repaint();

                fenetre.getContentPane().add(listeClientView);
                fenetre.revalidate();
                fenetre.repaint();


            }

            //###############LISTE DES VISITES PREVUES####################
            if (arg.equals(listeVisitesView)) {

                ListeVisitesModel listeVisitesModel = (ListeVisitesModel)application.getModels().get("listeVisites");
                //Suppression de la vue active
                fenetre.getContentPane().removeAll();

                //Récupération de la liste des visites correpondantes à la zone
                listeVisitesModel.create(application.getCommercial().getZone());

                //Paramétrage du Menu
                listeVisitesView.getMenu().getListeVisitesB().setBackground(Color.white);

                //Régénération du menu
                listeVisitesView.getMenu().revalidate();
                listeVisitesView.getMenu().repaint();


                //CAS: "il y a des visites de prévues."
                if (!listeVisitesModel.getVisites().getVisites().isEmpty()) {

                    //Génération de l'affichage de la liste des visites
                    ListeVisitesTable table = new ListeVisitesTable(listeVisitesModel.getVisites());
                    table.create();

                    //Ajout de l'affichage à la vue
                    listeVisitesView.getTabPan().setViewportView(table.getTable());


                    //CAS: "il y a des visites  de prévues."
                } else {

                    //Suppression de la vue actuelle
                    fenetre.getContentPane().add(listeClientView);

                    //Ajour d'un message d'erreur dans la vue
                    listeVisitesView.getTabPan().setViewportView(new JLabel("Aucunes visites de prévues pour l'instant."));

                }

                //Ajout de la nouvelle vue
                fenetre.getContentPane().add(listeVisitesView);

                //régénération de la Fenètre
                fenetre.validate();


                //########################AJOUTER UN RDV############################
            } else if (arg.equals(ajouterRdvView)) {

                AjouterRdvModel ajouterRdvModel = (AjouterRdvModel)application.getModels().get("ajouterRdv");

                //
                ajouterRdvModel.setCommercial(application.getCommercial());
                fenetre.getContentPane().removeAll();

                ajouterRdvView.setClients(ajouterRdvModel.getClientsDao().selectClients(application.getCommercial().getZone()).toCodeArray());
                ajouterRdvView.getChoixClient().setModel(new DefaultComboBoxModel(ajouterRdvView.getClients()));
                ajouterRdvView.getForm().revalidate();
                ajouterRdvView.getForm().repaint();
                ajouterRdvView.getMenu().getSavedRdV().setBackground(Color.white);
                ajouterRdvView.getMenu().revalidate();
                ajouterRdvView.getMenu().repaint();
                ajouterRdvView.revalidate();
                ajouterRdvView.repaint();


                fenetre.getContentPane().add(ajouterRdvView);
                fenetre.validate();
                fenetre.repaint();


            } else {


            }
        }

    }
}
