package controllers;

import gui.Application;
import gui.Fenetre;

import java.util.Observable;
import java.util.Observer;

/**
 * Created by guillaume on 01/05/16.
 */
abstract class Controller implements Observer{


    protected Fenetre fenetre;
    protected Application application;


    public Controller(Fenetre fenetre, Application application){


        this.fenetre = fenetre;
        this.application = application;


    }

    @Override
    public void update(Observable o, Object arg) {

    }
}



